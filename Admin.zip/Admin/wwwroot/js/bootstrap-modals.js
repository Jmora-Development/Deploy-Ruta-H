/*
 * Apertura y cierre de modales de Bootstrap desde Blazor (JS interop).
 * Restaurado del assets/js/main.js del template anterior (rama develop).
 * Lo usan las páginas tradicionales que invocan JSRuntime.InvokeVoidAsync("abrirModal" | "cerrarModal", id):
 * Aforos (ConsolidadoAforo, DetalleAforo), Seguridad (Roles, Usuarios) y Ruta Hospitalaria tradicional.
 * Los componentes nuevos usan AppModal (sin JavaScript).
 */
function cerrarModal(modalId) {
    var modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
    if (modal) {
        modal.hide();
    }
}

function abrirModal(modalId) {
    var modalElement = document.getElementById(modalId);
    if (modalElement) {
        var modal = new bootstrap.Modal(modalElement);
        modal.show();
    }
}
